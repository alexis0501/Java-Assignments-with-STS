package com.alexismayoral.bookclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookClubAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
