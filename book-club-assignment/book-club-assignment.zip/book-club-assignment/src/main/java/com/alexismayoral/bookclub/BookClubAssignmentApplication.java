package com.alexismayoral.bookclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookClubAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookClubAssignmentApplication.class, args);
	}

}
