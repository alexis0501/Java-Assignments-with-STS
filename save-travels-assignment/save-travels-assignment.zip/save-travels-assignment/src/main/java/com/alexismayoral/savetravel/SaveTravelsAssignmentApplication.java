package com.alexismayoral.savetravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveTravelsAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaveTravelsAssignmentApplication.class, args);
	}

}
