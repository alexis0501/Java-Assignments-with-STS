package com.alexismayoral.savetravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveTravelsAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
