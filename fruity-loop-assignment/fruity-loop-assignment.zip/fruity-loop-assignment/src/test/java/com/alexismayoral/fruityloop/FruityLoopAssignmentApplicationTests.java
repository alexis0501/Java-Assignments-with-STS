package com.alexismayoral.fruityloop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityLoopAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
