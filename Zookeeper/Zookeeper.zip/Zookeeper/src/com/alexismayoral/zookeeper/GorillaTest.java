package com.alexismayoral.zookeeper;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla harambe = new Gorilla();
		
		harambe.displayEnergy();
		
		harambe.throwSomething();
		harambe.throwSomething();
		harambe.throwSomething();
		
		harambe.eatBananas();
		harambe.eatBananas();
		
		harambe.throwSomething();
		
		harambe.displayEnergy();
	}
}
