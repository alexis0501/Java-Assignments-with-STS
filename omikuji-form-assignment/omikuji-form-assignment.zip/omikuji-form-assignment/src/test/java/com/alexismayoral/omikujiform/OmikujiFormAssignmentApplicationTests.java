package com.alexismayoral.omikujiform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiFormAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
